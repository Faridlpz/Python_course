def suma(a,b):
    print("El resultado de la suma es: ",a+b)

def restar(a,b):
    print("El resultado de la resta es: ",a-b)

def multiplicacion(a,b):
    print("El resultado de la multiplicacion es: ",a*b)


def dividir(a,b):
    print("El resultado de la division es: ",a/b)


def potencia(a,b):
    print("El resultado de la potencia es: ",a**b)


def redondear(a):
    print("El resultado de la redondeo es: ",round(a))
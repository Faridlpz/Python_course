from setuptools import setup, version
setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de operaciones matematicas",
    author="Farid",
    author_email="diraf_321@hotmail.com",
    packages=["paquete","paquete"]

)